from setuptools import setup

setup(name='pkg-nyakubava',
      version='0.0.1',
      description='Gaussian distributions',
      packages=['pkg-nyakubava'],
      author = 'Natallia Yakubava',
      auyhor_email = 'nyakubava@gmail.com',
      zip_safe=False)
